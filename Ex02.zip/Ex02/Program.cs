﻿using System.Drawing;
using UiManager;
//Rom Shemer 206662587
//Noa Altshuler 209281419

namespace Ex02
{
    public class Program
    {
        static void Main()
        {
            UserInterfaceManager u = new UserInterfaceManager();
            u.NewGame();
        }
    }
}
